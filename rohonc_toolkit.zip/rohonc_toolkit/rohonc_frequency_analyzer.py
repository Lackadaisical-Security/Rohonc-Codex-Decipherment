#!/usr/bin/env python3
"""Frequency analyzer for transcribed Rohonc symbol strings."""
from __future__ import annotations
import argparse
import csv
import math
import re
from collections import Counter
from pathlib import Path
import matplotlib.pyplot as plt

def tokenize(text: str):
    return [t for t in re.split(r'[\s\-|]+', text) if t and t != '|']

def shannon_entropy(counter: Counter) -> float:
    total = sum(counter.values())
    if total == 0:
        return 0.0
    ent = 0.0
    for count in counter.values():
        p = count / total
        ent -= p * math.log2(p)
    return ent

def ngrams(tokens, n):
    return [' '.join(tokens[i:i+n]) for i in range(len(tokens)-n+1)]

def main():
    p = argparse.ArgumentParser(description='Analyze frequency patterns in transcribed Rohonc text.')
    p.add_argument('--file', required=True, help='UTF-8 text file of transcribed Rohonc text')
    p.add_argument('--top', type=int, default=20)
    p.add_argument('--outdir', default='frequency_output')
    args = p.parse_args()

    text = Path(args.file).read_text(encoding='utf-8')
    tokens = tokenize(text)
    counter = Counter(tokens)
    bigrams = Counter(ngrams(tokens, 2))
    trigrams = Counter(ngrams(tokens, 3))
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    for name, data in [('symbols', counter), ('bigrams', bigrams), ('trigrams', trigrams)]:
        with open(outdir / f'{name}.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([name[:-1] if name.endswith('s') else name, 'count'])
            for item, count in data.most_common():
                writer.writerow([item, count])

    top_items = counter.most_common(args.top)
    labels = [k for k, _ in top_items]
    values = [v for _, v in top_items]
    plt.figure(figsize=(12, 6))
    plt.bar(range(len(values)), values)
    plt.xticks(range(len(labels)), labels, rotation=45, ha='right')
    plt.title('Top Rohonc Symbol Frequencies')
    plt.tight_layout()
    plt.savefig(outdir / 'top_symbols.png', dpi=200)
    plt.close()

    zipf_points = sorted(counter.values(), reverse=True)
    plt.figure(figsize=(8, 6))
    plt.loglog(range(1, len(zipf_points)+1), zipf_points, marker='o', linestyle='none')
    plt.xlabel('Rank')
    plt.ylabel('Frequency')
    plt.title('Zipf Plot for Rohonc Tokens')
    plt.tight_layout()
    plt.savefig(outdir / 'zipf_plot.png', dpi=200)
    plt.close()

    summary = outdir / 'summary.txt'
    summary.write_text(
        f'Total tokens: {len(tokens)}\n'
        f'Unique tokens: {len(counter)}\n'
        f'Shannon entropy: {shannon_entropy(counter):.4f} bits\n'
        f'Top {args.top} symbol frequencies saved to CSV/PNG.\n',
        encoding='utf-8'
    )
    print(summary)

if __name__ == '__main__':
    main()
