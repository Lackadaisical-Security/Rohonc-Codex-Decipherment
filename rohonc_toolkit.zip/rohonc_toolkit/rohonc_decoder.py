#!/usr/bin/env python3
"""Simple Rohonc Codex decoder/transliterator built from the uploaded research lexicons.

This tool is a reproducibility aid for the current project state.
It decodes transcribed Rohonc symbol strings using the provided JSON lexicons.
It does not perform OCR from scanned manuscript pages.
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent


def load_sources() -> tuple[dict, dict]:
    with open(ROOT / 'ROHONC_CODEX_LEXICON_COMPLETE.json', 'r', encoding='utf-8') as f:
        complete = json.load(f)
    with open(ROOT / 'rohonc_codex_script_lexicon.json', 'r', encoding='utf-8') as f:
        script = json.load(f)
    return complete, script


def build_maps() -> tuple[Dict[str, dict], Dict[str, dict], Dict[str, dict]]:
    complete, script = load_sources()
    symbol_map: Dict[str, dict] = {}
    phrase_map: Dict[str, dict] = {}
    formula_map: Dict[str, dict] = {}

    for item in complete.get('base_symbols', []):
        symbol_map[item['symbol']] = {
            'romanian': item.get('romanian') or item.get('meaning') or item.get('base_value'),
            'english': item.get('english') or item.get('meaning') or item.get('base_value'),
            'transliteration': item.get('base_value') or item.get('romanian') or item.get('meaning'),
            'source': 'base_symbols',
        }

    for item in script.get('entries', []):
        symbol_map.setdefault(item['symbol'], {
            'romanian': item.get('romanian_evolution', '').split('>')[0].strip() or item.get('transliteration') or item.get('meaning'),
            'english': item.get('meaning') or item.get('transliteration'),
            'transliteration': item.get('transliteration') or item.get('meaning'),
            'source': 'entries',
        })

    # Stable mappings stated in the research logs but not fully expanded in the JSON base-symbol list.
    supplemental = {
        '△': {'romanian': 'treime', 'english': 'trinity', 'transliteration': 'treime'},
        '✞': {'romanian': 'biserică', 'english': 'church', 'transliteration': 'biserică'},
        '⟁': {'romanian': 'rai', 'english': 'heaven', 'transliteration': 'rai'},
        '★': {'romanian': 'înger', 'english': 'angel', 'transliteration': 'înger'},
        '𐤋': {'romanian': 'rugăciune', 'english': 'prayer', 'transliteration': 'rugăciune'},
        '⛉': {'romanian': 'scut', 'english': 'shield', 'transliteration': 'scut'},
        '⚑': {'romanian': 'steag', 'english': 'banner', 'transliteration': 'steag'},
        '≈': {'romanian': 'apă', 'english': 'water', 'transliteration': 'apă'},
        '⩙': {'romanian': 'munte', 'english': 'mountain', 'transliteration': 'munte'},
        '🌿': {'romanian': 'copac', 'english': 'tree', 'transliteration': 'copac'},
    }
    for symbol, item in supplemental.items():
        symbol_map.setdefault(symbol, {**item, 'source': 'supplemental_logs'})

    for item in complete.get('common_words', []):
        phrase_map[item['rohonc']] = {
            'romanian': item.get('romanian'),
            'english': item.get('english'),
            'transliteration': item.get('romanian'),
            'source': 'common_words',
        }

    for item in complete.get('sample_texts', []):
        phrase_map[item['rohonc']] = {
            'romanian': item.get('romanian'),
            'english': item.get('english'),
            'transliteration': item.get('transliteration') or item.get('romanian'),
            'source': 'sample_texts',
        }

    for item in script.get('historical_formulas', []):
        formula_map[item['pattern']] = {
            'romanian': item.get('reading'),
            'english': item.get('meaning'),
            'transliteration': item.get('reading'),
            'source': 'historical_formulas',
        }

    return symbol_map, phrase_map, formula_map


def normalize(text: str) -> str:
    return re.sub(r'\s+', ' ', text.strip())


def decode_chunk(chunk: str, mode: str, symbol_map: Dict[str, dict], phrase_map: Dict[str, dict], formula_map: Dict[str, dict]) -> str:
    chunk = normalize(chunk)
    if chunk in phrase_map:
        return phrase_map[chunk][mode]
    if chunk in formula_map:
        return formula_map[chunk][mode]
    parts = [p for p in chunk.split('-') if p]
    out: List[str] = []
    for part in parts:
        item = symbol_map.get(part)
        out.append(item[mode] if item else part)
    return ' '.join(out)


def decode_text(text: str, mode: str = 'romanian') -> str:
    symbol_map, phrase_map, formula_map = build_maps()
    segments = re.split(r'\s*\|\s*', text.strip())
    decoded = [decode_chunk(seg, mode, symbol_map, phrase_map, formula_map) for seg in segments if seg.strip()]
    return ' | '.join(decoded)


def main() -> None:
    parser = argparse.ArgumentParser(description='Decode transcribed Rohonc Codex symbol strings.')
    parser.add_argument('text', nargs='?', help='Transcribed Rohonc text, e.g. "⊕-☦-△-✝ | ♔-✋"')
    parser.add_argument('--file', help='Path to a UTF-8 text file containing transcribed Rohonc text.')
    parser.add_argument('--mode', choices=['romanian', 'english', 'transliteration'], default='romanian')
    args = parser.parse_args()

    if not args.text and not args.file:
        parser.error('Provide either text or --file')
    text = Path(args.file).read_text(encoding='utf-8') if args.file else (args.text or '')
    print(decode_text(text, mode=args.mode))


if __name__ == '__main__':
    main()
